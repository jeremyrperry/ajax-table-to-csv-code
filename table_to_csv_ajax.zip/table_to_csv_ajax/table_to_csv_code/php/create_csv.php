<?php

function csv_convert($the_val, $val_position){
	$csv_terminated = "\n";
    $csv_separator = ",";
    $csv_enclosed = '"';
    $csv_escaped = "\\";
	$new_line_replace = array("</p>", "<br />", "<br>");
	$val_output = stripslashes(stripslashes($the_val));
	$val_output = str_replace("<p>", "", $val_output);
	$val_output = str_replace($new_line_replace, '\n', $val_output);
	$val_output = str_replace($csv_enclosed, $csv_escaped . $csv_enclosed, $val_output);
	$val_output = $csv_enclosed . $val_output . $csv_enclosed;
	if($val_position == "false"){
		$val_output .= $csv_separator;
	}
	else{
		$val_output .= $csv_terminated;
	}
	return $val_output;
}

ini_set("auto_detect_line_endings", true);
if(isset($_REQUEST['csv_export'])){
	$record_content = "";
	$delimiter = "|";
	if(isset($_REQUEST['delimiter'])){
		$delimiter = $_REQUEST['delimiter'];
		$dr = array('"', "'");
		$delimiter = str_replace($dr, "", $delimiter);
	}
	$file_name = $_REQUEST['file_name'];
	$record_header = explode($delimiter, $_REQUEST['record_header']);
	$header_count = count($record_header);
	$count = 1;
	foreach($record_header as $header){
		$last = "false";
		if($count == $header_count){
			$last = "true";
			$count = 1;
		}
		else{
			$count++;
		}
		$record_content .= csv_convert($header, $last);

	}
	$data_string = explode("<br />", $_REQUEST['data_string']);
	foreach($data_string as $ds){
		$record_file = explode($delimiter, $ds);
		foreach($record_file as $record){
			$last = "false";
			if($count == $header_count){
				$last = "true";
				$count = 1;
			}
			else{
				$count++;
			}
			$record_content .= csv_convert($record, $last);

		}
	}
	$status = "success";
	$file_path = "temp_files/" . $file_name;
	if(file_exists($file_path)){
		unlink($file_path);
	}
	$csv_file = fopen($file_path, "w");
	fwrite($csv_file, $record_content);
	fclose($csv_file);
	$output = array(
		'status'=>$status,
		'file_name'=>$file_name,
		'file_path'=>dirname(__FILE__)."/temp_files/"
	);
	print json_encode($output);
}

?>