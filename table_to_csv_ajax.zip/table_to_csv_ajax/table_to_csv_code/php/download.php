<?php

function download_file ($file, $type, $file_path, $delete_file)
{
		//Begin writing headers
		header ('Pragma: public') ;
		header ('Expires: 0') ;
		header ('Cache-Control: must-revalidate, post-check=0, pre-check=0') ;
		header ('Cache-Control: public') ;
		header ('Content-Description: File Transfer') ;

		//Use the switch-generated Content-Type
		header ('Content-Type: ' . $content_type) ;

		//Force the download - set the headers
		if($type == "file"){
			$name = $file;
		}
		else{
			$name = $filename;
		}
		header ('Content-Disposition: attachment; filename=' . $name . ';') ;
		header ('Content-Transfer-Encoding: binary') ;

	//Now read the file and exit
	if($type == "file"){
		print file_get_contents($file_path . $file) ;
		if($delete_file == "true"){
			unlink($file_path . $file);
		}
	}
	else{
		print $file;
	}
	exit ;
}


if(isset($_REQUEST['file_name'])){
	$file_name = $_REQUEST['file_name'];
	$delete_file = "false";
	if(isset($_REQUEST['delete_file'])){
		$delete_file = $_REQUEST['delete_file'];
	}
	$file_path = $_REQUEST['file_path'];
	download_file($file_name, "file", $file_path, $delete_file);
}

?>